<?php
/**
 * Created by PhpStorm.
 * User: selim
 * Date: 12/9/2015
 * Time: 11:07 AM
 */

return [
    'modules'=>array(
        "user",
        "admin",
        "slm",
    ),
];