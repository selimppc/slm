<?php
/**
 * Created by PhpStorm.
 * User: etsb
 * Date: 2/17/16
 * Time: 4:25 PM
 */

namespace App\Modules\User\Controllers;

use App\Http\Controllers\Controller;
class CheckController extends Controller
{

    public function check()
    {
        echo "OK";
    }
}