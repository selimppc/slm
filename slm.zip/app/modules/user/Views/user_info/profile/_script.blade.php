<script>

    $(function(){

        $('#datapicker2').datepicker();
        $('.input-group.date').datepicker({ });
        $('.input-daterange').datepicker({ });


    });

</script>