

--
-- Dumping data for table `role_user`
--

INSERT INTO `role_user` (`id`, `role_id`, `user_id`, `remember_token`, `status`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 1, 1, NULL, 'active', 1, 0, '2016-03-03 08:05:43', '2016-03-03 08:05:43'),
(2, 2, 2, NULL, 'active', 1, 0, '2016-03-03 08:18:05', '2016-03-03 08:18:05');

