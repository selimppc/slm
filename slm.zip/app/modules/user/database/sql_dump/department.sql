

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `title`, `description`, `slug`, `status`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Marketing Department', 'Marketing Department', 'marketing-department', 'active', 0, 0, '2016-03-03 08:06:48', '2016-03-03 08:06:48'),
(2, 'Medicine Department', 'Medicine Department', 'medicine-department', 'active', 0, 0, '2016-03-03 08:07:03', '2016-03-03 08:07:03');

