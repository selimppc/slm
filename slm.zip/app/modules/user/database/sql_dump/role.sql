

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `title`, `slug`, `status`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin', 'active', 1, 0, '2016-03-03 08:05:24', '2016-03-03 08:05:24'),
(2, 'user', 'user', 'active', 1, 0, '2016-03-03 08:05:29', '2016-03-03 08:05:29');

