@extends('admin::bitd_layout.master')
@section('sidebar')
    @include('admin::bitd_layout._sidebar')
@stop
{{----}}
@section('content')
    <div class="content animate-panel">
        <div class="row">
            content..............
        </div>
    </div>
@stop