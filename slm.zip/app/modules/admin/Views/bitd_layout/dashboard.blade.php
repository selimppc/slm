@extends('admin::layouts.master')
{{--@section('sidebar')--}}
{{--@include('admin::layouts.sidebar')--}}
{{--@stop--}}
{{----}}
@section('content')
    <div class="content animate-panel">
        <div class="row">
            Welcome To Dashboard.....
        </div>
    </div>
@stop