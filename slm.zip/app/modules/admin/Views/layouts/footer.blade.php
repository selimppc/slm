<footer class="footer">
        <h6 class="text-center">
            COPYRIGHT © <?php echo date('Y'); ?> · ALL RIGHTS RESERVED Surinam Airways
        </h6>

</footer>