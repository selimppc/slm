@extends('admin::layouts.master')

@section('content')

    <div class="row">
        <div class="col-lg-12">
            <img src="{{ URL::to('/') }}/assets/img/poster.jpg" alt="poster" class="poster"></a>
        </div>
    </div>
@stop