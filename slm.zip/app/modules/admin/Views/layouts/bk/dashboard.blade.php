@extends('admin::layouts.master')
@section('sidebar')
    @include('admin::layouts.sidebar')
@stop
<div style="background-image:url('{{ URL::asset("assets/user/img/chain.jpg")}}') ;height: 100%; width: 100%; ">
@section('content')



        <h2>Welcome To Dashboard.....</h2>
    </div>

@stop